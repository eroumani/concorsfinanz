﻿// Contextor Studio
// Auto-generated declaration file : do not modify !



var RataNetApp = ctx.addApplication('RataNetApp', {"nature":"WEB3","path":"https://green-1.commerzfinanz.com/"});

RataNetApp.pRequestList = RataNetApp.addPage('pRequestList', {"comment":"[mainFrame] - https://green-1.commerzfinanz.com/ratanet/front?controller=CreditApplication action=AgencyContractsList ps=null init=0","path":"https://green-1.commerzfinanz.com/ratanet/front?controller=CreditApplication\u0026action=AgencyContractsList\u0026ps=null\u0026init=0"});
RataNetApp.pRequestList.edSearchRequestId = RataNetApp.pRequestList.addItem('edSearchRequestId');
RataNetApp.pRequestList.btRequest = RataNetApp.pRequestList.addItem('btRequest', {"occurs":1});
RataNetApp.pRequestList.btSearch = RataNetApp.pRequestList.addItem('btSearch');
RataNetApp.pRequestList.oListe = RataNetApp.pRequestList.addItem('oListe', {"mustExist":true});
RataNetApp.pRequestList.lbValue = RataNetApp.pRequestList.addItem('lbValue', {"occurs":1});

RataNetApp.pContract = RataNetApp.addPage('pContract', {"comment":"[mainFrame] - Kreditvertrag","path":"https://green-1.commerzfinanz.com/ratanet/front?controller=CreditApplication\u0026action=GoInitAnalyseDossier\u0026contractno=20513207\u0026IsAlreadyExported=0\u0026vendorid=2200020"});
RataNetApp.pContract.edNewNoteText = RataNetApp.pContract.addItem('edNewNoteText');
RataNetApp.pContract.btNewNoteAdd = RataNetApp.pContract.addItem('btNewNoteAdd');
RataNetApp.pContract.lbExistingNotes = RataNetApp.pContract.addItem('lbExistingNotes', {"occurs":1});
RataNetApp.pContract.btUnlock = RataNetApp.pContract.addItem('btUnlock');
RataNetApp.pContract.cbNewNoteCode = RataNetApp.pContract.addItem('cbNewNoteCode');
RataNetApp.pContract.oSSButton = RataNetApp.pContract.addItem('oSSButton');

RataNetApp.menuBar = RataNetApp.addPage('menuBar', {"comment":"[leftFrame] - Commerz Finanz GmbH","path":"https://green-1.commerzfinanz.com/ratanet/web/cetelem/menu.jsp"});
RataNetApp.menuBar.btStop = RataNetApp.menuBar.addItem('btStop');


var OutlookUIApp = ctx.addApplication('OutlookUIApp', {"nature":"UIAUTOMATION"});

OutlookUIApp.pMain = OutlookUIApp.addPage('pMain', {"comment":"Window - Inbox - T.Waggoner@commerzfinanz.com - Microsoft Outlook"});
OutlookUIApp.pMain.btNeueEMailNachricht = OutlookUIApp.pMain.addItem('btNeueEMailNachricht', {"mustExist":true});
OutlookUIApp.pMain.tblInbox = OutlookUIApp.pMain.addItem('tblInbox');

OutlookUIApp.pEmail = OutlookUIApp.addPage('pEmail', {"comment":"Window - FW: CFG Ctrix Desktop Portal - Nachricht (HTML) "});
OutlookUIApp.pEmail.btAntworten = OutlookUIApp.pEmail.addItem('btAntworten', {"mustExist":true});

GLOBAL.events.START.on(function(ev) { 
    GLOBAL.createExtendedConnector(e.extendedConnector.UIAutomation, '', '', '');
});
