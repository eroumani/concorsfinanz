﻿ctx.tooltips = {};
ctx.tooltipPlacements = {};

ctx.test = function(text) {
	alert(text);
}

/**
 * @method initialize
**/
ctx.initialize = function(params) {
	if (typeof params === 'object') {
		//uncomment to display content for testing
		//var output = JSON.stringify(params, null, 2); alert(output);
		var obj = {};
		for (var id in params) {
			if (id == 'header')
				obj.title = params[id]; // rename 'header' to 'title'
			else
				obj[id] = params[id];
		}
	    if (obj.form && (typeof obj.form === 'object')) {
	        if (typeof obj.message === 'undefined') { obj.message = ''; }
	        // build XML structure (as a JSON object) from form descriptor
	        var descObj = { form: obj.form };
	        var domObj = { };
	        ctx.buildMessage(descObj, domObj);
            // stringify and parse object to 'clean it up' (remove 'undefined' attributes, not supported by json2xml)
            var jsonMessage = JSON.stringify(domObj);
            var dom = JSON.parse(jsonMessage);
            obj.message += json2xml(dom);
        }

		// set mandatory options
		obj.container = '#dialogDiv';
		obj.closeButton = false;
		obj.backdrop = false;
		obj.animate = false;
		obj.show = false;
		ctx.setProcessName(obj.appliName);
		ctx.setPageName(obj.pageName);
		ctx.setEventName(obj.eventName);
		//obj.size = obj.size || "small";
		obj.message = obj.message || " "; // can not be empty

		if (obj.buttons) {
		    $.each(obj.buttons, function (key, button) {
		        // use key as name
	            button.name = button.name || button.id || key;
		        // if no label, use name as label
	            button.label = button.label || button.value || button.name;
		        // set default class
				if (button.tooltip) {
					ctx.tooltips[button.name] = button.tooltip;
				}
				if (button.tooltipPlacement) {
					ctx.tooltipPlacements[button.name] = button.tooltipPlacement;					
				}
		        if (!button.className)
		            button.className = 'btn-default';
		        if (button.type)
		            button.className = 'btn-' + button.type;
		        if (button.className.indexOf('btn-') == -1)
		            button.className = 'btn-' + button.className;
	            button.className += ' btn-custom';
		        // if call back undefined, set it to "close('id')"
		        if (!button.callback) { 
					var submit = ((button.type == "submit")  || button.submit);
					var close = (button.close !== false);
					button.callback = function (event) {
						return ctx.sendValues(button.name, submit, close);
					}
                }
		    });
		}

		// customize 'escape key' action
		if (obj.escape !== undefined)
			obj.onEscape = function () { return ctx.close(obj.escape || ''); }

		// build dialog object				
		var dialog = bootbox.dialog(obj);

		if (obj.buttons) {
		    $.each(obj.buttons, function (key, button) {
		        // add glyphicon if defined : (add 'glyphicon-' prefix if needed (ex.: 'pushpin' --> 'glyphicon-pushpin'))
		        if (button.icon) {
		            if (button.icon.indexOf('glyphicon-') == -1)
		                button.icon = 'glyphicon-' + button.icon;
		            var bt = $("button[data-bb-handler='" + key + "']");
		            bt.text(' ' + bt.text());
					bt.attr('name', button.name);
		            var span = "<span class='glyphicon " + button.icon + "'/>";
		            bt.prepend(span);
		        }
		    });
		}

		// add optional icon to the template
		if (obj.icon) {
			var icon = "<div class='icon-class'><img src='" + obj.icon + "'/></div>";
			//var body = dialog.find(".bootbox-body");
			var body = dialog.find(".modal-body");
			if (body) {
			    body.before(icon);
			    //body.addClass("right-col");
			}
		}

		// add optional classes to the template
		if (obj.classes) {
			for (var className in obj.classes) {
				var node = dialog.find("." + className);
				if (node) {
					node.addClass(obj.classes[className]);
				}
			}
		}

		// add color class
		if (obj.color) {
			var node = dialog.find(".modal-dialog");
			if (node) {
				node.addClass(obj.color);
			}
		}

		// add optional auto-close to the template
		if (obj.autoClose) {
			autoClose = parseInt(obj.autoClose, 10); // timeout in 'ms'
			if (autoClose > 0) {
				setTimeout(function() { ctx.close(obj.escape || ''); }, autoClose);
			}
		}

		if (obj.closeOnClick) {
			dialog.on("click", ".modal-body", function(e) {
			  return ctx.close(obj.escape || '');
			});
		}
		
		// hide shadow around dialog
		$('.modal-content').removeClass('modal-content');

		$('.modal-dialog').attr('id', 'popupDiv');

		// display dialog
		dialog.modal("show");
		
		// enable tooltips
		//$('[data-toggle="tooltip"]').tooltip(); 
		for (var id in ctx.tooltips) {
			$('[name="' + id + '"]').tooltip({title: ctx.tooltips[id], html: true, placement: ctx.tooltipPlacements[id] || "bottom"});
		}
		
		//focus in the first visible input
		$('input:visible').first().focus();
	 
	}
}

ctx.getClass = function(obj) {
    var cls = obj.className || '';
    if (obj.width)
        cls += ' col-xs-' + obj.width;
    if (obj.offset)
        cls += ' col-xs-offset-' + obj.offset;
    return cls;
}

ctx.update = function(obj) {
    return cls;
}

ctx.getJSValues = function() {
	return $('form').serializeJSON();
}

ctx.getValues = function() {
	var resObj = ctx.getJSValues();
	var result = '!json:' + JSON.stringify(resObj);
    return result;
}

ctx.close = function(result) {
	// Default close funtion : set value in 'Ctx_Result' div, then click on 'Ctx_Close'
	Ctx_Result.value = result || '';
	Ctx_Close.click();
	//window.open('','_self').close();
	//window.close();
}

ctx.sendValues = function(key, submit, close) {
	var data;
	if (submit) {
		var resObj = ctx.getJSValues();
		resObj.button = key;
		data = '!json:' + JSON.stringify(resObj);
	} else {
		data = key;
	}
	if (close) {
		// Default close funtion : set value in 'Ctx_Result' div, then click on 'Ctx_Close'
		ctx.close(data);
	} else {
		ctx.sendEvent('', data);
	}
    return (close ? true : false);
}


ctx.buildMessage = function(descObj, domObj) {
    var obj;
    var dom;
    var cls;
    var isArray = false;
    // first loop on attributes
    for (var id in descObj) {
        obj = descObj[id];
        if (Object.prototype.toString.call(obj) === '[object Array]') {
            isArray = true;
        }
        cls = ctx.getClass(obj);
		var type;
		type = descObj[id].type || id; // if type is not mentioned, use node name as type (ex.: 'label')
		if (obj.icon) {
			if (obj.icon.indexOf('glyphicon-') == -1)
				obj.icon = 'glyphicon-' + obj.icon;
		}
		if (obj.tooltip) {
			ctx.tooltips[id] = obj.tooltip;
		}
		if (obj.tooltipPlacement) {
			ctx.tooltipPlacements[id] = obj.tooltipPlacement;					
		}
        switch (type) {
            case 'form':
                dom = domObj.form = {
                    '@id': obj.id || " inputForm",
                    //'@method': "post",
                    '@class': cls + ' bootbox-form form-horizontal',
                    '@role': "form",
                    '@data-toggle': "validator"
                }
                // build children
                ctx.buildMessage(obj, dom);
                break;
            case 'group':
                if (isArray) {
                    domObj.div = [];
                    for (var groupId in obj) {
                        cls = ctx.getClass(obj[groupId]);
                        dom = {
                            '@class': cls + ' form-group'
                        }
                        // build children
                        ctx.buildMessage(obj[groupId], dom);
                        domObj.div.push(dom);
                    }
                };
                break;
            case 'row':
                if (isArray) {
                    domObj.div = {
                        '@class': 'row col-xs-12',
                        div: []
                    };
                    for (var rowId in obj) {
                        cls = ctx.getClass(obj[rowId]);
                        dom = {
                            '@class': cls
                        }
                        // build children
                        ctx.buildMessage(obj[rowId], dom);
                        domObj.div.div.push(dom);
                    }
                };
                break;
            case 'label':
                dom = domObj.label = {
                    '@class': cls + ' control-label',
                    '#text': obj.value
                };
                break;
            case 'text':
            case 'url':
            case 'email':
            case 'date':
            case 'time':
            case 'number':
            case 'password':
                domObj.div = {
                    '@class': cls,
                    input: {
						'@type': type,
                        '@class': 'bootbox-input bootbox-input-' + type + ' form-control',
						'@name': id,
    	                '@control': obj.control,
    	                '@value': obj.value,
    	                '@disabled': obj.disabled,
                        '@data-role': obj.role
                    }
                };
                break;
            case 'textarea':
                domObj.div = {
                    '@class': cls,
                    textarea: {
                        '@class': 'form-control',
						'@name': id,
                        '@rows': obj.rows,
                        '@control': obj.control,
                        '#text': obj.value
                    }
                };
                break;
            case 'radio':
            case 'checkbox':
                domObj.div = domObj.div || [];
                dom = {
                    '@class': cls,
                    div: []
                };
                for (var opt in obj.options) {
                    var checked = undefined;
                    if (obj.value == opt) {
                        // single value
                        checked = true;
                    } else {
                        // array or object value
                        for (var i in obj.value) {
                            if (obj.value[i] == opt) {
                                checked = true;
                                break;
                            }
                        }
                    }
                    dom.div.push({
                        "@class": obj.className || id,
                        "label": {
                            "input": {
                                "@type": type,
								"@name": id,
                                "@checked": checked,
                                "@value": opt
                            }
                        },
                        "#text": obj.options[opt]
                    });
                }
                domObj.div.push(dom);
                break;
            case 'select':
                domObj.div = {
                    '@class': cls,
					select : {
						'@class': 'form-control',
						'@name': id,
						'@control': obj.control,
                        '#text': obj.value,
						option: []
					}
				}
                for (var opt in obj.options) {
                    domObj.div.select.option.push({
                        '@value': opt,
                        '#text': obj.options[opt]
                    });
                }
                break;
            case 'button':
            case 'submit':
				domObj.button = domObj.button || [];
				var action = "ctx.sendValues('" + id + "', " + (((type == "submit") || obj.submit) ? 'true' : 'false') + ", " + (obj.close ? 'true' : 'false') + ");";
				dom = {
					span: (obj.icon ? { '@class': 'glyphicon ' + obj.icon } : undefined),
					'@class': 'btn btn-custom ' + cls,
					'@type': type,
					'@name': id,
					'@data-bb-handler': id,
					'@control': obj.control,
					'@disabled': obj.disabled,
					'@data-role': obj.role,
					'@onClick': action,
					'#text': (obj.icon ? ' ' : '') + (obj.value || id)
				};

				domObj.button.push(dom);
                break;
            default:
                // by default, copy attribute 'as is'
				if(id=="width"){
					domObj['@class'] += " col-xs-"+obj;
				}
                domObj['@'+id] = obj;
                break;
        }
    }
}

// function aliases
var initialize = ctx.initialize;
var update = ctx.update;
var getValues = ctx.getValues;
var getJSValues = ctx.getJSValues;

var close = ctx.close;
