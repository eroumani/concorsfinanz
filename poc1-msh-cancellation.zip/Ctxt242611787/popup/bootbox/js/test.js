﻿
$(function() {
    // uncomment one line below to test page in standalone mode, inside I.E.
    //initTooltip() // tooltip popup
	//initPopupBuilder();
	//init(); // simple display dialog box
    //init2(); // simple form dialog box
    //init3(); // complex form dialog box
    //init5(); // simple form dialog box for diagnostic
	//initUser();
});

//    Simply call it from: $(function() { ... }
function init() {
	var obj = {
	    message: "<H4>Hello world</H4>I am a custom dialog<br/><b>bla bla bla</b><br/><font color='red'>bla bla bla<br/>bla bla bla bla bla bla bla bla bla bla bla bla bla bla bla</font><br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla",
	    iconIcon: "../bmp32/user.png",
	    title: "<img src='../bmp32/user.png'/>  <b>Custom title</b>",
	    icon: "../bmp64/comp6.png",
	    autoClose: 30000,
		color: "yellow",
		escape: 'cancel',
		buttons: [
	        {
				id: "ok",
		        label: "Ok",
		        type: "warning",
                icon: "check"
	        },
            {
				id: "cancel",
		        label: "Cancel",
				type: "default",
                icon: "flash"
	        },
	        {
				id: "main",
		        type: "link",
		        type: "link",
		        label: "Click ME",
				close: false,
		        icon: "pushpin"
	        }
        ]
	};
	initialize(obj);
}

function initTooltip() {
	var obj = {
	    message: "<b>I am a tooltip</b><br/>Add extra information below<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla<br/>bla bla bla",
	    icon: "../bmp32/galaxy.png",
	    color: "yellow",
	    autoClose: 10000,
		closeOnClick: true,
		classes: {
			'modal-dialog': 'modal-dialog-tooltip',
			'modal-body': 'modal-body-tooltip',
			'icon-class': 'icon-class-tooltip'
		},
		buttons: {}
	};
	initialize(obj);
}

// *** this function is just for testing in standalone mode, inside I.E. ***
//    Simply call it from: $(function() { ... }
function init2() {
	var obj = {
	    message: '',
	    header: "<b>Set username and password</b>",
	    color: "blue",
	    form: {
            id: 'inputForm',
	        group: [{
	            label: {
	                value: "Username",
                    width: 3
	            },
                text: {
	                name: "username",
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Password",
                    width: 3
	            },
                password: {
                    name: "password",
	                width: 5
	            }
	        },
	        {
    	        row: [{
                    width: 8,
	                label: {
	                    value: "Movie title"
	                },
	                text: {
	                    name: "title"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Genre"
                    },
                    select: {
                        name: "genre",
                        options: {
                            action: 'Action',
                            comedy: 'Comedy',
                            horror: 'Horror',
                            romance: 'Romance'
                        }
                    }
                }]
	        },
	        {
    	        row: [{
                    width: 4,
	                label: {
	                    value: "Director"
	                },
	                text: {
	                    name: "director"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Writer"
                    },
	                text: {
	                    name: "writer"
	                }
                },
                {
                    width: 4,
                    label: {
                        value: "Producer"
                    },
	                text: {
	                    name: "producer"
	                }
                }]
	        },
	        {
    	        row: [{
                    width: 6,
	                label: {
	                    value: "Website"
	                },
	                text: {
	                    name: "website"
	                }
                },
                {
                    width: 6,
                    label: {
                        value: "Youtube trailer"
                    },
	                text: {
	                    name: "trailer"
	                }
                }]
	        },
	        {
                width: 12,
	            label: {
	                value: "Review"
	            },
	            textarea: {
	                name: "review",
	                rows: 8,
	                value: "中华人民共和国大使馆驻法兰\n المملكةالعربيةالسعو  \nФедераПОСО ЛЬСТСИЙСКОЙ $ €"
	            }
	        },
	        {
                width: 12,
	            label: {
	                value: "Rating"
	            },
	            radio: {
	                name: "rating",
	                value: "watchable",
	                className: "radio-inline",
	                options: {
	                    terrible: 'Terrible',
	                    watchable: 'Watchable',
                        best: 'Best ever'
                    }
	            }
	        },
	        {
	            label: {
	                value: "Genre",
	                width: 3
	            },
	            radio: {
	                name: "gender",
	                value: "male",
	                options: {
	                    male: 'Male',
	                    female: 'Female',
	                    other: 'Other'
	                },
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Browser",
	                width: 3
	            },
	            checkbox: {
	                name: "browsers[]",
	                value: ["firefox", "ie"],
	                options: {
	                    chrome: 'Google Chrome',
	                    firefox: 'Firefox',
	                    ie: 'IE',
	                    safari: 'Safari',
	                    opera: 'Opera',
	                    other: 'Other'
	                },
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Cities",
	                width: 3
	            },
	            text: {
	                name: "cities",
	                value: "Paris",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
	                value: "Countries",
	                width: 3
	            },
	            text: {
	                name: "countries",
	                value: "France",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
	                value: "ID",
	                width: 3
	            },
	            text: {
	                name: "id",
	                value: "2",
	                disabled: "disabled",
	                width: 3
	            }
	        },
	        {
	            label: {
	                value: "Email",
	                width: 3
	            },
	            email: {
	                name: "email",
	                value: "support@contextor.eu",
	                control: "email",
	                width: 5
	            }
	        },
	        {
	            label: {
	                value: "Website",
	                width: 3
	            },
	            text: {
	                name: "website",
	                value: "www.contextor.eu",
	                control: "website",
	                width: 5
	            }
	        }
            /*,{
                row:[{
	                offset: 3,
	                width: 5,
	                button: [{
                        type: 'submit',
				        className: "btn btn-primary",
                        value: "Login",
                        icon: "check"
	                },
	                {
				        className: "btn btn-default",
                        value: "Cancel",
                        icon: "flash"
	                }]
                }]
	        }*/
            ]
        },
		buttons: {
	        Login: {
		        type: "submit",
				className: "btn btn-primary",
                icon: "check"
	        },
            Cancel: {
		        type: "button",
				className: "btn btn-default",
                icon: "flash"
	        }
        }
	};
	initialize(obj);
}

function init3() {
	var obj = {
		appliName: 'GLOBAL',
		pageName: 'pBootbox',
		eventName: 'evNotification',
	    message: '',
	    header: "<b>Set username and password</b>",
	    form: {
            id: 'inputForm',
	        group: [{
	            label: {
					type: "label",
	                value: "Username",
                    width: 3
	            },
                username: {
					type: "text",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Password",
                    width: 3
	            },
                password: {
					type: "password",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Review"
	            },
	            review: {
					type: "textarea",
	                rows: 8,
	                value: "中华人民共和国大使馆驻法兰\n المملكةالعربيةالسعو  \nФедераПОСО ЛЬСТСИЙСКОЙ $ €"
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Cities",
	                width: 3
	            },
	            cities: {
					type: "text",
	                value: "Paris",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Countries",
	                width: 3
	            },
	            countries: {
					type: "text",
	                value: "France",
	                role: "tagsinput",
	                width: 8
	            }
	        },
	        {
				label: {
					type: "label",
					value: "ID",
					width: 3
				},
				id: {
					type: "text",
					value: "6",
					disabled: "disabled",
					width: 2
				},
				start: {
					type: "button",
					value: "Start",
					className: "btn btn-success",
					tooltip: 'Click to start',
					tooltipPlacement: 'top',
					icon: "check",
					close: false,
					width: 2
				},
				stop: {
					type: "button",
					value: "Stop",
					className: "btn btn-danger",
					tooltip: 'Click to stop',
					tooltipPlacement: 'top',
					icon: "flash",
					close: false,
					width: 2
				}
	        },
			{
				labelDate: {
					type: e.popup.formType.Label,
					value: "Date",
					width: 3
				},
				date: {
					type: e.popup.formType.Date,
					value: "",
					width: 3
				}
			},
			{
				labelTime: {
					type: e.popup.formType.Label,
					value: "Time",
					width: 3
				},
				time: {
					type: e.popup.formType.Time,
					value: "",
					width: 3
				}
			},
			{
				labelAge: {
					type: e.popup.formType.Label,
					value: "Age",
					width: 3
				},
				age: {
					type: e.popup.formType.Number,
					value: "",
					width: 3
				}
			},
	        {
	            label: {
					type: "label",
	                value: "Email",
	                width: 3
	            },
	            email: {
					type: "email",
	                value: "support@contextor.eu",
	                control: "email",
	                width: 5
	            }
	        },
	        {
	            label: {
					type: "label",
	                value: "Website",
	                width: 3
	            },
	            website: {
					type: "text",
	                value: "www.contextor.eu",
	                control: "website",
	                width: 5
	            }
	        }
            /*,{
                row:[{
	                offset: 3,
	                width: 5,
	                button: [{
                        type: 'submit',
				        className: "btn btn-primary",
                        value: "Login",
                        icon: "check"
	                },
	                {
				        className: "btn btn-default",
                        value: "Cancel",
                        icon: "flash"
	                }]
                }]
	        }*/
            ]
        },
		buttons: {
	        login: {
		        type: "submit",
		        value: "Login",
				tooltip: 'Click to submit',
				tooltipPlacement: 'top',
				className: "btn btn-primary",
                icon: "check"
	        },
            cancel: {
		        type: "button",
		        value: "Cancel",
				tooltip: 'Click to cancel',
				tooltipPlacement: 'top',
				className: "btn btn-default",
                icon: "flash"
	        }
        }
	};
	initialize(obj);

}

/*function init4() {
	bootbox.prompt({
		header: "What is your real name?",
		value: "makeusabrew",
		callback: function(result) {
			if (result === null) {
				Example.show("Prompt dismissed");
			} else {
				Example.show("Hi <b>"+result+"</b>");
			}
		}
	});
}*/

function init5() {
	var obj = {
		appliName: 'GLOBAL',
		pageName: 'pBootbox',
		eventName: 'evNotification',
	    //header: "<b>Issue report</b>",
	    //message: '<b>Bla bla bla...</b><br/>Bla bla bla...<br/><br/>',
	    form: {
            id: 'inputForm',
	        group: [
			{
				row: [{
                    width: 2,
	                labelDiag: {
						type: "label",
						value: "Diagnostic",
						width: 12,
						tooltip: 'Click to save desktop and Contextor diagnostic'
					}
                },
				{
                    width: 3,
	                saveDiag: {
						type: "button",
						submit: true,
						value: "Save",
						icon: "flash",
						tooltip: 'Click to save desktop and Contextor diagnostic',
						width: 12,
						className: "btn-primary"
					}
                }]
			},
			{
				row: [{
                    width: 2,
	                labelDiag: {
						type: "label",
						value: "Recording",
						width: 12,
					}
                },
				{
                    width: 3,
	                start: {
						type: "button",
						submit: true,
						value: "Start",
						icon: "play",
						tooltip: 'Click to start recording',
						width: 12,
						className: "btn-success"
					}
                },
				{
                    width: 3,
	                stop: {
						type: "button",
						submit: true,
						value: "Stop",
						icon: "stop",
						disabled: true,
						visible: false,
						width: 12,
						tooltip: 'Click to stop recording',
						className: "btn-danger"
					}
                }]
			},
			/*{
				label: {
				  value: "",
				  width: 2
				},
				checkbox: {
				  name: "diagOptions[]",
				  value: ["dump"],
				  options: {
					soft: 'Include software list',
					dump: 'Include crash dumps'
				  },
				  width: 9
			    }
	        },*/
			  {
				label: {
				  value: "",
				  width: 2
				},
				checkbox: {
				  name: "recordOptions[]",
				  disabled: true,
				  value: ["screenshot", "auto"],
				  options: {
					screenshot: 'Include screenshots',
					auto: 'Auto-recording (for each scenario)'
				  },
				  width: 9
			    }
	        },
			{
				row: [{
                    width: 2,
	                labelComment: {
						type: "label",
						value: "Comment",
						width: 12
					}
                },
				{
                    width: 3,
	                addComment: {
						type: "button",
						submit: true,
						value: "Add comment",
						icon: "pencil",
						tooltip: 'Click to insert a comment<br/> - bla bla bla<br/> - bla bla bla',
						width: 12,
						className: "btn-primary"
					}
                }]
			},
	        {
	            comment: {
					type: "textarea",
	                rows: 10,
	                value: "",
					tooltipPlacement: 'top',
					width: 12
	            }
	        },
			{
				row: [
				{
                    offset: 8,
                    width: 3,
	                close: {
						type: "button",
						value: "Close",
						icon: "check",
						tooltip: 'Click to close Issue report window',
						tooltipPlacement: 'top',
						width: 12,
						close: true,
						className: "btn-default"
					}
                }]
			},
            ]
        }
	};
	initialize(obj);

}

function initPopupBuilder() {
	var obj = {
		template: e.popup.template.FormSubmit,
		title: 'Enter popup data',
		form: {
			group: [{
				labelType: { 
					type: e.popup.formType.Label, 
					width:3, 
					value: 'Type'
				},
				type: { 
					type: e.popup.formType.Radio, 
					width: 9, 
					value: 'popup',
					options: {
						tooltip: 'Tooltip',
						popup: "Popup"
					}
				}
			}, {
				labelIcon: { 
					type: e.popup.formType.Label, 
					width:3, 
					value: 'Icon'
				},
				icon: { 
					type: e.popup.formType.Select, 
					width: 9, 
					value: 'User',
					options: {
						contextor: 'Contextor',
						accept: "Ok",
						cancel: "Error",
						help: "Help",
						none: 'None',
						information: "Information",
						user: "User",
						warning: "Warning"
					}
				}
			}, {
				labelColor: { 
					type: e.popup.formType.Label, 
					width:3, 
					value: 'Color'
				},
				color: { 
					type: e.popup.formType.Select, 
					width: 9, 
					value: (alert ? 'yellow' : 'none'),
          options: {
					  blue:   'Blue',
					  green:  'Green',
					  none:   'None',
					  orange: 'Orange',
					  red:    'Red',
					  yellow: 'Yellow'
			    }
				}
			}, {
				labelTitle: { type: e.popup.formType.Label, width:3, value: 'Title'},
				title: { type: e.popup.formType.Text, width: 9, value: 'Hello world !' }
			}, {
				text: { 
					type: e.popup.formType.TextArea, 
					width: 12, 
					rows : 5,
					value: 'ab hac discrevimus, Commagena,\net civitatibus amplis inlustris.' }
			}]
		},
		buttons: {
	        send: {
		        type: e.popup.buttonStyle.Blue,
				icon: e.popup.buttonIcon.flash,
				//callback: function() {
				//	var res = popup.getJSValues();
				//	sendPopup(res);
				//},
				close: false,
		        label: "Send"
	        }
        }
		
	};
	initialize(obj);
}

function initUser() 
{
	obj = {
		template: e.popup.template.FormSubmit,
		title: 'Bootbox Login form',
		color: e.popup.color.Yellow,
		CX: 600,
		CY: 280,
    form: {
			id: 'inputForm',
			group: [
        {
          labelID: {
						type: e.popup.formType.Label,
            value: "ID",
            width: 2
          },
          id: {
						type: e.popup.formType.Text,
            value: "2",
            disabled: true,
            width: 5
          },
          hello: {
						type : e.popup.formType.Button,
						submit : true,
						value : "Start",
						icon : "play",
						tooltip : 'Click to start recording',
						width : 3,
						className : "btn-success"
          }
        },
        {
            labelName: {
								type: e.popup.formType.Label,
                value: "Full name",
                width: 2
            },
            name: {
								type: e.popup.formType.Text,
                value: "John Smith",
                width: 10
            }
        },
        {
            labelEmail: {
								type: e.popup.formType.Label,
                value: "Email",
                width: 2
            },
            email: {
				type: e.popup.formType.Text,
                value: "jsmith@contextor.eu",
                width: 10
            }
        },
        {
            labelWebsite: {
								type: e.popup.formType.Label,
                value: "Website",
                width: 2
            },
            website: {
								type: e.popup.formType.Text,
                value: "www.contextor.eu",
                control: "website",
                width: 10
            }
        }
			]
		}
	}
	initialize(obj);
}
	
/*$(document).ready(function () {
    $('#userForm')
        .formValidation({
            framework: 'bootstrap',
            icon: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {
                name: {
                    validators: {
                        notEmpty: {
                            message: 'The full name is required'
                        },
                        regexp: {
                            regexp: /^[a-zA-Z\s]+$/,
                            message: 'The full name can only consist of alphabetical characters'
                        }
                    }
                },
                email: {
                    validators: {
                        notEmpty: {
                            message: 'The email address is required'
                        },
                        emailAddress: {
                            message: 'The email address is not valid'
                        }
                    }
                },
                website: {
                    validators: {
                        notEmpty: {
                            message: 'The website address is required'
                        },
                        uri: {
                            allowEmptyProtocol: true,
                            message: 'The website address is not valid'
                        }
                    }
                }
            }
        })
});*/

