﻿var StopRequest = false;

GLOBAL.events.START.on(function() {

	/** Find the next cancellation email and transfer it to RataNet */
	GLOBAL.scenario({ scTransferNextEmail: function(ev, sc) {
		var data = sc.data;
		sc.onTimeout(60000, function(sc, st) {
			ShowTooltip("Timeout", "Automatische Verarbeitung abgebrochen. Bitte neu starten,", e.popup.color.Red);
			ctx.log("Timeout", e.logIconType.Error);
			StopRequest = true;
			sc.data.nxt = "stop";
			sc.endScenario();	
		}); // default timeout handler for each step
		sc.onError(function(sc, st, ex) {
			ShowTooltip("Fehler", "Automatische Verarbeitung abgebrochen. Bitte neu starten,", e.popup.color.Red);
			ctx.log(ex, e.logIconType.Error);
			StopRequest = true;
			sc.data.nxt = "stop";
			sc.endScenario();	
		}); // default error handler
		sc.onEnd(function(sc, st) {
			ctx.log("Scenario ended");
			//Next one -- Give contextor time to handle other events
			ctx.wait(function() {
				if(sc.data.nxt === "continue" && StopRequest==false){
						GLOBAL.scenarios.scTransferNextEmail.start();
				}
			}, 500);
			//DONE
		});
		sc.setMode(e.scenario.mode.clearIfRunning);
		
		sc.step(GLOBAL.steps.stCheckPrerequisites);
		sc.step(GLOBAL.steps.stFindNextEmail);
		sc.step(GLOBAL.steps.stFindRataNetContract);
		sc.step(GLOBAL.steps.stUpdateRataNet);
		sc.step(GLOBAL.steps.stShowConfirmation);
		
	}});

	
	/** Description */
	GLOBAL.step({ stCheckPrerequisites: function(ev, sc, st) {
		var data = sc.data;
		ctx.log("Check prereqisites");
		
		if(!OutlookUIApp.exist() || ! RataNetApp.exist()){
			ShowTooltip("Fehler","Outlook und Ratanet müssen gestartet sein");
			sc.endScenario();
		}
		
		sc.endStep();
	}});
	
	
	/** Scan Outlook to find the next cancellaation email */
	GLOBAL.step({ stFindNextEmail: function(ev, sc, st) {
		var data = sc.data;
		ctx.log("Find Next Email");
		
		var olFolderInbox =	6;
		var outlookApp = new ActiveXObject("outlook.Application");
		var inbox = outlookApp.Session.GetDefaultFolder(olFolderInbox);
		var stornos = inbox.Folders("Stornos");
		var archive = stornos.Folders("Saturn Stornos Erledigt");
		
		ctx.log("Stornos: " + stornos.Items.Count());
		
		for( var i = 1	; i <= stornos.Items.Count() ; i++) {
			var nxtMail = stornos.Items.Item(i);
			
			if(nxtMail.ConversationTopic.indexOf('STORNO')==0){
				ctx.log("FOUND Mail");
				ctx.log("from: " + nxtMail.ReceivedByName);
				ctx.log("to: " + nxtMail.SenderName);
				ctx.log("subject: " + nxtMail.ConversationTopic);
				ctx.log("body: " + nxtMail.Body);
				ctx.log("==========================================");
				
				var fullBody = nxtMail.body;
				var value = fullBody.substring(fullBody.indexOf("Stornobetrag:") + 14, fullBody.indexOf("Order-ID")-5).replace(".","").replace(",",".").trim();
				ctx.log("Value: " + value);
				if(isNaN(value)){
					ShowTooltip("Anfragenummer " + data.requestId + ". Konnte Betrag nicht lesen.", "Bitte Storno manuell bearbeiten");
					data.nxt = "stop";
					sc.endScenario();
					return;
				}
				
				var requestId = nxtMail.ConversationTopic.substr(nxtMail.ConversationTopic.length-8, 8);
				data.requestId=requestId;
				
				var sentDate = new Date( nxtMail.SentOn + "");
				ctx.log(sentDate + "");
				
				data.requestDate = sentDate.getDate() + "." + (sentDate.getMonth() + 1) + "." + sentDate.getFullYear();
				data.mailItem = nxtMail;
				data.value = value;
				data.nxt="continue";
				nxtMail.UnRead = false;
				nxtMail.Move(archive);
				nxtMail.Display();
				sc.endStep();
				return;
			}
		}
		//No more emails: We are done:
		ShowTooltip("Fertig","Keine weiteren MSH Cancellation Emails gefunden");
		RataNetApp.menuBar.btStop.click();
		data.nxt = "stop";
		sc.endScenario();
	}});
		
	
	/** Find and open the contract in RataNet */
	GLOBAL.step({ stFindRataNetContract: function(ev, sc, st) {
		var data = sc.data;
		ctx.log("Find RataNet contract: " + data.requestId);
		if(RataNetApp.pContract.exist()){
			RataNetApp.pContract.btUnlock.click();
		}

		RataNetApp.pRequestList.wait(function(){
			RataNetApp.pRequestList.edSearchRequestId.set(data.requestId);
			RataNetApp.pRequestList.btSearch.click();
			ctx.wait(function(){
				if(RataNetApp.pRequestList.btRequest.count()!=1) {
					ShowTooltip("Anfragenummer " + data.requestId + " nicht gefunden", "Bitte Storno manuell bearbeiten");
					data.nxt = "stop";
					sc.endScenario();
					return;
				}
				
				var value = RataNetApp.pRequestList.lbValue.i(1).get().replace(".","").replace(",",".").trim();
				value = value.substring(0, value.length - 2);
				if(isNaN(value)){
					ShowTooltip("Anfragenummer " + data.requestId + ". Konnte Betrag nicht lesen.", "Bitte Storno manuell bearbeiten");
					data.nxt = "stop";
					sc.endScenario();
					return;
				}
				if(Number(value) != Number(data.value)){
					ShowTooltip("Anfragenummer " + data.requestId + ". Teilstorno.", "Bitte Storno manuell bearbeiten");
					data.nxt = "stop";
					sc.endScenario();
					return;
				}
				RataNetApp.pRequestList.btRequest.i(0).click();

				RataNetApp.pContract.wait(function(){
					sc.endStep();			
				});
			}, 500);
		});
	}});
	
	
	/** Insert info in RataNet*/
	GLOBAL.step({ stUpdateRataNet: function(ev, sc, st) {
		var data = sc.data;
		ctx.log("Update RataNet");
		
		for (var i = 0; i < RataNetApp.pContract.lbExistingNotes.count(); i++) {
			if(RataNetApp.pContract.lbExistingNotes.i(i).get().indexOf("HDL SS liegt vor")>-1){
				RataNetApp.pContract.scrollTo(0, 2500);
				ShowTooltip("Achtung", "Die Storno Information scheint schon vorhanden zu sein und wurde nicht noch einmal hinzugefügt. Bitte prüfen.", e.popup.color.Red);
				ctx.wait(function(){
					sc.endStep();
				}, 3000)
				return;
			}
		}
		
		RataNetApp.pContract.edNewNoteText.set("HDL SS liegt vor//DS " + data.requestDate);
		RataNetApp.pContract.btNewNoteAdd.click();
		
		sc.endStep();
	}});
	
	
	/** Description */
	GLOBAL.step({ stShowConfirmation: function(ev, sc, st) {
		var data = sc.data;
		ctx.log("Show confirmation");
		
		RataNetApp.pContract.scrollTo(0, 2500);
		
		ShowTooltip("Prüfung", "Bitte Storno prüfen und abschließen");

		RataNetApp.pContract.waitClose(function(){
			hideToolTip();
			try{
				data.mailItem.Close(1);
			} catch(ex) {
				//Nothing to do here.
			}

			sc.endStep();
		});
	}});
		
	
});

var myPopup;

function ShowTooltip(headline, body, color){
	
	if(!color) color = e.popup.color.Yellow;
	
	myPopup = ctx.popup('pTT1').open({
		template: e.popup.template.TooltipAlert,
		CX: 400,
		message: '<b>' + headline + '</b><br/>' + body + '<br/>', 
		icon: e.popup.icon32.info,
		color: color,
		autoClose: 10000
	});
}

function hideToolTip(){
	myPopup.close();
}